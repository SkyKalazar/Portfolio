package Model.SearchItems;

public interface SearchItem
{
   String getTitle();

   String getDetails();

   String getContactInfo();

   String getPostcode();
}
