package Model.ViewModelInterfaces;

public interface UserModel
{
  String getUsername();

  boolean isProfessional(String username);
}
