package Model.ViewModelInterfaces;

import Model.FAQ.FAQ;

public interface FAQModel extends UserModel
{
  FAQ getFaqs();
}
