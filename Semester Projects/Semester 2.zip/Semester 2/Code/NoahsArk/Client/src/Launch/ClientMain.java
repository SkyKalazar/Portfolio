package Launch;

import javafx.application.Application;

public class ClientMain
{
   public static void main(String[] args)
   {
      Application.launch(Launch.MyApplication.class);
   }
}
